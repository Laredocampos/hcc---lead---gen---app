# HCC Lead Gen App

This is a simple lead generation React app for HCC General Contracting.

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Create a `.env` file in the root:

   ```
   VITE_EMAILJS_SERVICE_ID=your_service_id
   VITE_EMAILJS_TEMPLATE_ID=your_template_id
   VITE_EMAILJS_USER_ID=your_user_id
   ```

3. Run locally:

   ```bash
   npm run dev
   ```

## Deploy

- Push to GitHub
- Import to Vercel
- Add environment variables in the dashboard

