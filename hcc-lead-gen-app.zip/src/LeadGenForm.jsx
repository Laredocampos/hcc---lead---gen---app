import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import emailjs from "@emailjs/browser";

const SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID;
const TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
const USER_ID = import.meta.env.VITE_EMAILJS_USER_ID;

export default function LeadGenForm() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    city: "",
    service: "",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const allowedCities = [
      "Houston TX",
      "Livingston TX",
      "Conroe TX",
      "Splendora TX",
      "Cleveland TX",
      "Spring TX",
      "The Woodlands TX",
      "Pasadena TX"
    ];

    if (!allowedCities.includes(form.city)) {
      alert("Sorry, we currently serve only specific areas in Texas: " + allowedCities.join(", "));
      return;
    }

    try {
      await emailjs.send(SERVICE_ID, TEMPLATE_ID, form, USER_ID);
      setSubmitted(true);
      setForm({ name: "", email: "", phone: "", city: "", service: "", message: "" });
    } catch (error) {
      console.error("EmailJS Error:", error);
      alert("Failed to send lead. Please try again later.");
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-xl mx-auto p-4">
      <Card className="rounded-2xl shadow-xl p-6">
        <CardContent>
          <h2 className="text-2xl font-bold mb-4">Get a Free Estimate</h2>
          {submitted ? (
            <p className="text-green-600 text-lg">Thank you! We'll contact you shortly.</p>
          ) : (
            <form onSubmit={handleSubmit} className="grid gap-4">
              <Input name="name" placeholder="Full Name" value={form.name} onChange={handleChange} required />
              <Input name="email" type="email" placeholder="Email" value={form.email} onChange={handleChange} required />
              <Input name="phone" type="tel" placeholder="Phone Number" value={form.phone} onChange={handleChange} required />
              <Input name="city" placeholder="City (e.g. Houston TX)" value={form.city} onChange={handleChange} required />
              <Input name="service" placeholder="What service are you interested in? (e.g. Gutters, Kitchen Renovation)" value={form.service} onChange={handleChange} required />
              <Textarea name="message" placeholder="Additional details (optional)" value={form.message} onChange={handleChange} />
              <Button type="submit" className="w-full">Submit Lead</Button>
            </form>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
